"""API routes for AI Service."""


