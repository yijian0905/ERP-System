﻿# ERP Backend Deployment Package

Generated: 2025-12-21 08:22:14

## Contents

- pps/api/ - Node.js API Service (Fastify)
- pps/ai-service/ - Python AI Service (FastAPI)
- packages/ - Shared packages (database, logger, shared-types, config)
- docker-compose.yml - Docker orchestration

## Quick Start with Docker

1. **Upload this package to your server**

2. **Create environment files:**
   ```bash
   cp apps/api/env.example.txt apps/api/.env
   cp apps/ai-service/env.example.txt apps/ai-service/.env
   ```

3. **Edit the .env files with production values**

4. **Start the services:**
   ```bash
   # Start PostgreSQL and Redis first
   docker-compose up -d postgres redis

   # Wait for databases to be ready, then start API
   docker-compose up -d api

   # Optionally start AI service (requires --profile ai)
   docker-compose --profile ai up -d ai-service
   ```

## Manual Deployment (Without Docker)

### API Service (Node.js)

```bash
cd apps/api

# Install pnpm if not installed
npm install -g pnpm@9.14.2

# Go back to root and install dependencies
cd ../..
pnpm install

# Build the project
pnpm build

# Start the API service
cd apps/api
pnpm start
```

### AI Service (Python)

```bash
cd apps/ai-service

# Create virtual environment
python -m venv venv

# Activate (Linux/Mac)
source venv/bin/activate
# Or on Windows
# .\venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Start the service
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## Environment Variables

### API Service (.env)

| Variable | Description | Example |
|----------|-------------|---------|
| PORT | Server port | 3000 |
| NODE_ENV | Environment | production |
| DATABASE_URL | PostgreSQL connection | postgresql://user:pass@host:5432/db |
| REDIS_URL | Redis connection | redis://host:6379 |
| JWT_SECRET | JWT signing key | (generate secure key) |
| JWT_REFRESH_SECRET | Refresh token key | (generate secure key) |
| LICENSE_ENCRYPTION_KEY | License encryption | (32+ chars) |
| LHDN_ENCRYPTION_KEY | LHDN API encryption | (64 hex chars) |
| AI_SERVICE_URL | AI service URL | http://ai-service:8000 |

### AI Service (.env)

| Variable | Description | Example |
|----------|-------------|---------|
| PORT | Server port | 8000 |
| ENVIRONMENT | Environment | production |
| DATABASE_URL | PostgreSQL connection | postgresql://user:pass@host:5432/db |
| REDIS_URL | Redis connection | redis://host:6379 |
| CORS_ORIGINS | Allowed origins | https://your-domain.com |

## Ports

- API Service: 3000
- AI Service: 8000
- PostgreSQL: 5432
- Redis: 6379

## Health Checks

- API: GET http://localhost:3000/health
- AI: GET http://localhost:8000/health
