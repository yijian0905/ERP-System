/**
 * Data Module Exports
 */

export * from './mock-data.js';

