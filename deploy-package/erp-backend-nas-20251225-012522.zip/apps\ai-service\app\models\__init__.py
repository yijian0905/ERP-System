"""ML models for forecasting and optimization."""


